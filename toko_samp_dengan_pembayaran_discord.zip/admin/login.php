<?php
session_start(); require '../api/config.php';
if(isset($_SESSION['admin'])){header('Location:index.php');exit;}
$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 $s=$pdo->prepare("SELECT * FROM admins WHERE username=?");$s->execute([$_POST['username']??'']);$a=$s->fetch();
 if($a && password_verify($_POST['password']??'',$a['password_hash'])){$_SESSION['admin']=$a['username'];header('Location:index.php');exit;}
 $error='Username atau password salah.';
}
?>
<!doctype html><html lang="id"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Admin Toko SAMP</title>
<style>body{font-family:Arial;background:#28002f;display:grid;place-items:center;min-height:100vh}.box{background:#fff;padding:25px;border-radius:18px;width:min(380px,90%)}input,button{width:100%;padding:14px;margin:7px 0}button{background:#6240f5;color:white;border:0;border-radius:22px;font-weight:bold}</style>
<div class="box"><h2>🔐 Admin Toko SAMP</h2><form method="post"><input name="username" placeholder="Username" required><input name="password" type="password" placeholder="Password" required><button>LOGIN</button></form><p><?=$error?></p></div></html>