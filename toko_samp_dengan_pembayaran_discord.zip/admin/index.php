<?php
session_start(); if(!isset($_SESSION['admin'])){header('Location:login.php');exit;}
require '../api/config.php';
if(isset($_POST['status'],$_POST['id'])){
 $q=$pdo->prepare("UPDATE orders SET status=? WHERE id=?");$q->execute([$_POST['status'],(int)$_POST['id']]);
}
$rows=$pdo->query("SELECT o.*,p.name product FROM orders o JOIN products p ON p.id=o.product_id ORDER BY o.id DESC")->fetchAll();
?>
<!doctype html><html lang="id"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Dashboard Toko SAMP</title>
<style>body{font-family:Arial;margin:0;background:#f5eef7}.top{background:#381340;color:white;padding:18px}.wrap{padding:18px;max-width:1100px;margin:auto}.table{overflow:auto;background:white;border-radius:15px}table{border-collapse:collapse;width:100%}th,td{padding:12px;border-bottom:1px solid #ddd;text-align:left}select,button{padding:8px}button{background:#6240f5;color:white;border:0;border-radius:8px}</style>
<div class="top"><b>💎 Admin Toko SAMP</b> — <a style="color:white" href="logout.php">Logout</a></div>
<div class="wrap"><h2>Daftar Order</h2><div class="table"><table><tr><th>Kode</th><th>Player</th><th>Produk</th><th>Total</th><th>Status</th><th>Waktu</th></tr>
<?php foreach($rows as $r):?><tr><td><?=$r['order_code']?></td><td><?=htmlspecialchars($r['player_id'])?></td><td><?=htmlspecialchars($r['product'])?></td><td>Rp<?=number_format($r['amount'],0,',','.')?></td><td><form method="post"><input type="hidden" name="id" value="<?=$r['id']?>"><select name="status"><option <?=$r['status']=='pending'?'selected':''?>>pending</option><option <?=$r['status']=='paid'?'selected':''?>>paid</option><option <?=$r['status']=='processing'?'selected':''?>>processing</option><option <?=$r['status']=='done'?'selected':''?>>done</option><option <?=$r['status']=='cancelled'?'selected':''?>>cancelled</option></select><button>Simpan</button></form></td><td><?=$r['created_at']?></td></tr><?php endforeach;?></table></div></div></html>