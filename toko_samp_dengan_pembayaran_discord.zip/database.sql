CREATE DATABASE IF NOT EXISTS toko_samp CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE toko_samp;
CREATE TABLE products (
 id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(100) NOT NULL,description VARCHAR(255),
 price INT NOT NULL,active TINYINT(1) DEFAULT 1
);
INSERT INTO products(name,description,price) VALUES
('VIP Bronze','30 Hari',10000),('VIP Silver','30 Hari',25000),
('VIP Gold','30 Hari',50000),('Paket Sultan','Bonus spesial',100000);
CREATE TABLE orders (
 id INT AUTO_INCREMENT PRIMARY KEY,order_code VARCHAR(30) UNIQUE NOT NULL,
 player_id VARCHAR(100) NOT NULL,product_id INT NOT NULL,amount INT NOT NULL,
 status ENUM('pending','paid','processing','done','cancelled') DEFAULT 'pending',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(product_id) REFERENCES products(id)
);
CREATE TABLE admins (
 id INT AUTO_INCREMENT PRIMARY KEY,username VARCHAR(50) UNIQUE NOT NULL,
 password_hash VARCHAR(255) NOT NULL
);
