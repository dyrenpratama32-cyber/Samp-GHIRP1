<?php
$host='localhost';
$db='toko_samp';
$user='root';
$pass='';

$midtrans_server_key='ISI_SERVER_KEY_MIDTRANS';
$midtrans_client_key='ISI_CLIENT_KEY_MIDTRANS';
$midtrans_production=false; // false = sandbox, true = production

$discord_webhook_url='ISI_DISCORD_WEBHOOK_URL';

$pdo=new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4",$user,$pass,[
 PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
 PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC
]);
header('Content-Type: application/json; charset=utf-8');
