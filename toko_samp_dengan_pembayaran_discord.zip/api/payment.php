<?php
require 'config.php';
if($_SERVER['REQUEST_METHOD']!=='POST'){http_response_code(405);echo json_encode(['message'=>'Method tidak diizinkan']);exit;}
$in=json_decode(file_get_contents('php://input'),true);
$player=trim($in['player_id']??'');$pid=(int)($in['product_id']??0);
if($player===''||strlen($player)>100||$pid<1){http_response_code(422);echo json_encode(['message'=>'Data order tidak valid']);exit;}
$s=$pdo->prepare("SELECT id,name,price FROM products WHERE id=? AND active=1");$s->execute([$pid]);$p=$s->fetch();
if(!$p){http_response_code(404);echo json_encode(['message'=>'Produk tidak ditemukan']);exit;}
$code='SAMP-'.date('ymdHis').'-'.strtoupper(bin2hex(random_bytes(3)));
$q=$pdo->prepare("INSERT INTO orders(order_code,player_id,product_id,amount,status) VALUES(?,?,?,?,?)");
$q->execute([$code,$player,$p['id'],$p['price'],'pending']);

$payload=[
 'transaction_details'=>['order_id'=>$code,'gross_amount'=>(int)$p['price']],
 'item_details'=>[['id'=>(string)$p['id'],'price'=>(int)$p['price'],'quantity'=>1,'name'=>$p['name']]],
 'customer_details'=>['first_name'=>$player]
];
$url=$midtrans_production?'https://app.midtrans.com/snap/v1/transactions':'https://app.sandbox.midtrans.com/snap/v1/transactions';
$ch=curl_init($url);
curl_setopt_array($ch,[
 CURLOPT_RETURNTRANSFER=>true,CURLOPT_POST=>true,
 CURLOPT_HTTPHEADER=>['Accept: application/json','Content-Type: application/json','Authorization: Basic '.base64_encode($midtrans_server_key.':')],
 CURLOPT_POSTFIELDS=>json_encode($payload),CURLOPT_TIMEOUT=>30
]);
$res=curl_exec($ch);$codeHttp=curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);
$data=json_decode($res,true);
if($codeHttp<200||$codeHttp>=300||empty($data['token'])){
 $pdo->prepare("UPDATE orders SET status='cancelled' WHERE order_code=?")->execute([$code]);
 http_response_code(502);echo json_encode(['message'=>'Gateway pembayaran belum siap. Cek Server Key Midtrans.']);exit;
}
if($discord_webhook_url && strpos($discord_webhook_url,'ISI_')!==0){
 $content="🛒 **ORDER BARU Toko SAMP**\nKode: `{$code}`\nPlayer: `".str_replace('`','',$player)."`\nProduk: **{$p['name']}**\nTotal: **Rp".number_format($p['price'],0,',','.')."**\nStatus: `pending`";
 $ch=curl_init($discord_webhook_url);curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_POST=>true,CURLOPT_HTTPHEADER=>['Content-Type: application/json'],CURLOPT_POSTFIELDS=>json_encode(['content'=>$content]),CURLOPT_TIMEOUT=>10]);curl_exec($ch);curl_close($ch);
}
echo json_encode(['token'=>$data['token'],'order_code'=>$code]);
