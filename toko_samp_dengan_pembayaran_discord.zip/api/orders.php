<?php
require 'config.php';
if($_SERVER['REQUEST_METHOD']!=='POST'){http_response_code(405);echo json_encode(['message'=>'Method tidak diizinkan']);exit;}
$in=json_decode(file_get_contents('php://input'),true);
$player=trim($in['player_id']??''); $pid=(int)($in['product_id']??0);
if($player===''||strlen($player)>100||$pid<1){http_response_code(422);echo json_encode(['message'=>'Data order tidak valid']);exit;}
$s=$pdo->prepare("SELECT id,name,price FROM products WHERE id=? AND active=1");$s->execute([$pid]);$p=$s->fetch();
if(!$p){http_response_code(404);echo json_encode(['message'=>'Produk tidak ditemukan']);exit;}
$code='SAMP-'.date('ymd').'-'.strtoupper(bin2hex(random_bytes(3)));
$q=$pdo->prepare("INSERT INTO orders(order_code,player_id,product_id,amount) VALUES(?,?,?,?)");
$q->execute([$code,$player,$p['id'],$p['price']]);
echo json_encode(['message'=>'Pesanan berhasil dibuat.','order_code'=>$code]);
