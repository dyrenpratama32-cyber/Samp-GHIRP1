<?php
require 'config.php';
$body=file_get_contents('php://input');$n=json_decode($body,true);
if(!$n){http_response_code(400);exit('invalid');}
$order=$n['order_id']??'';$status=$n['transaction_status']??'';$gross=$n['gross_amount']??'';
$sig=$n['signature_key']??'';
$expected=hash('sha512',$order.($n['status_code']??'').$gross.$midtrans_server_key);
if(!$sig||!hash_equals($expected,$sig)){http_response_code(403);exit('invalid signature');}
$new='pending';
if(in_array($status,['settlement','capture'],true) && (($n['fraud_status']??'accept')==='accept'||$status==='settlement'))$new='paid';
elseif(in_array($status,['expire','cancel','deny'],true))$new='cancelled';
elseif($status==='pending')$new='pending';
$pdo->prepare("UPDATE orders SET status=? WHERE order_code=?")->execute([$new,$order]);
if($new==='paid' && $discord_webhook_url && strpos($discord_webhook_url,'ISI_')!==0){
 $content="✅ **PEMBAYARAN BERHASIL**\nKode: `{$order}`\nStatus: `paid`";
 $ch=curl_init($discord_webhook_url);curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_POST=>true,CURLOPT_HTTPHEADER=>['Content-Type: application/json'],CURLOPT_POSTFIELDS=>json_encode(['content'=>$content]),CURLOPT_TIMEOUT=>10]);curl_exec($ch);curl_close($ch);
}
http_response_code(200);echo 'OK';
