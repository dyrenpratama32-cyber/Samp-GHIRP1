<?php
require 'config.php';
echo json_encode($pdo->query("SELECT id,name,description,price FROM products WHERE active=1 ORDER BY id")->fetchAll());
